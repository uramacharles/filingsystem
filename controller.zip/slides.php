
    <!--Main Slider-->
    <section class="main-slider" id="scroll-section-one" data-start-height="900" data-slide-overlay="yes">
     
        <div class="tp-banner-container">
            <div class="tp-banner">
                <ul>
                    <li data-transition="zoomin" data-slotamount="1" data-masterspeed="1000" data-thumb="asset/images/slide1.jpg"  data-saveperformance="off"  data-title="">
                         <img src="asset/images/slide1.jpg"  alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">
                         
                         <div class="tp-caption sfr sfb tp-resizeme"
                         data-x="center" data-hoffset="0"
                         data-y="center" data-voffset="-100"
                         data-speed="1500"
                         data-start="500"
                         data-easing="easeOutExpo"
                         data-splitin="none"
                         data-splitout="none"
                         data-elementdelay="0.01"
                         data-endelementdelay="0.3"
                         data-endspeed="1200"
                         data-endeasing="Power4.easeIn"><h3 class="text-center"> We are out to give you a desired <br> ease in your work. Are you a lawyer? <br>Then this is a good place for you <br> to be.</h3></div>
                         
                         <div class="tp-caption sfl sfb tp-resizeme"
                         data-x="center" data-hoffset="0"
                         data-y="center" data-voffset="150"
                         data-speed="1500"
                         data-start="500"
                         data-easing="easeOutExpo"
                         data-splitin="none"
                         data-splitout="none"
                         data-elementdelay="0.01"
                         data-endelementdelay="0.3"
                         data-endspeed="1200"
                         data-endeasing="Power4.easeIn"><a href="register.php" class="theme-btn btn-style-three">Register</a></div>
                    </li>                    
                    <li data-transition="zoomout" data-slotamount="1" data-masterspeed="1000" data-thumb="asset/images/slide2.PNG"  data-saveperformance="off"  data-title="">
                         <img src="asset/images/slide2.PNG"  alt=""  data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" style="">

                         <div class="tp-caption sft sfb tp-resizeme"
                         data-x="center" data-hoffset="0"
                         data-y="center" data-voffset="-100"
                         data-speed="1500"
                         data-start="500"
                         data-easing="easeOutExpo"
                         data-splitin="none"
                         data-splitout="none"
                         data-elementdelay="0.01"
                         data-endelementdelay="0.3"
                         data-endspeed="1200"
                         data-endeasing="Power4.easeIn"><h3 class="text-center">We give you a platform, where you can <br> arrange your work for printing. <br>You can now do your typing online.</b></h3></div>
                         
                         <div class="tp-caption sfb sfb tp-resizeme"
                         data-x="center" data-hoffset="0"
                         data-y="center" data-voffset="150"
                         data-speed="1500"
                         data-start="500"
                         data-easing="easeOutExpo"
                         data-splitin="none"
                         data-splitout="none"
                         data-elementdelay="0.01"
                         data-endelementdelay="0.3"
                         data-endspeed="1200"
                         data-endeasing="Power4.easeIn"><a href="login.php" class="theme-btn btn-style-one">Login</a></div>
                    </li>
               
                    
                    <li data-transition="fadeinright" data-slotamount="1" data-masterspeed="1000" data-thumb="asset/images/slide3.jpg"  data-saveperformance="off"  data-title="">
                         <img src="asset/images/slide3.jpg"  alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">
                         
                         
                         <div class="tp-caption sft sfb tp-resizeme"
                         data-x="center" data-hoffset="0"
                         data-y="center" data-voffset="-100"
                         data-speed="1500"
                         data-start="500"
                         data-easing="easeOutExpo"
                         data-splitin="none"
                         data-splitout="none"
                         data-elementdelay="0.01"
                         data-endelementdelay="0.3"
                         data-endspeed="1200"
                         data-endeasing="Power4.easeIn"><h3 class="text-center">Do you have a file you want to keep <br> confidential? We are here to give you <br>the support you need.</h3></div>
                         
                         <div class="tp-caption sfb sfb tp-resizeme"
                         data-x="center" data-hoffset="0"
                         data-y="center" data-voffset="150"
                         data-speed="1500"
                         data-start="500"
                         data-easing="easeOutExpo"
                         data-splitin="none"
                         data-splitout="none"
                         data-elementdelay="0.01"
                         data-endelementdelay="0.3"
                         data-endspeed="1200"
                         data-endeasing="Power4.easeIn"><a href="register.php" class="theme-btn btn-style-one">Register</a></div>
                    </li>
                    <li data-transition="zoomin" data-slotamount="1" data-masterspeed="1000" data-thumb="asset/images/slide4.jpg"  data-saveperformance="off"  data-title="">
                         <img src="asset/images/slide4.jpg"  alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">
                         
                         <div class="tp-caption sft sfb tp-resizeme"
                         data-x="center" data-hoffset="0"
                         data-y="center" data-voffset="-100"
                         data-speed="1500"
                         data-start="500"
                         data-easing="easeOutExpo"
                         data-splitin="none"
                         data-splitout="none"
                         data-elementdelay="0.01"
                         data-endelementdelay="0.3"
                         data-endspeed="1200"
                         data-endeasing="Power4.easeIn"><h3 class="text-center">Upload your court Images, Files, Documents, etc. <br> Avoid easy loss or misplacement <br> of documents.</h3></div>
                         
                         <div class="tp-caption sfb sfb tp-resizeme"
                         data-x="center" data-hoffset="0"
                         data-y="center" data-voffset="150"
                         data-speed="1500"
                         data-start="500"
                         data-easing="easeOutExpo"
                         data-splitin="none"
                         data-splitout="none"
                         data-elementdelay="0.01"
                         data-endelementdelay="0.3"
                         data-endspeed="1200"
                         data-endeasing="Power4.easeIn"><a href="login" class="theme-btn btn-style-one">Login</a></div>
                    </li>
                    
                </ul>
                
               <div class="tp-bannertimer"></div>
            </div>
        </div>
    </section>